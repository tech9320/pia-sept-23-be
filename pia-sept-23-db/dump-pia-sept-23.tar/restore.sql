--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Ubuntu 15.4-2.pgdg22.04+1)
-- Dumped by pg_dump version 16.0 (Ubuntu 16.0-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "pia-sept-23";
--
-- Name: pia-sept-23; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE "pia-sept-23" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "pia-sept-23" OWNER TO admin;

\connect -reuse-previous=on "dbname='pia-sept-23'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: doctor; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.doctor (
    id integer NOT NULL,
    "userName" character varying NOT NULL,
    password character varying NOT NULL,
    "firstName" character varying NOT NULL,
    "lastName" character varying NOT NULL,
    address character varying NOT NULL,
    phone character varying NOT NULL,
    email character varying NOT NULL,
    "profilePic" character varying,
    "licenceNumber" character varying NOT NULL,
    "officeDepartment" character varying NOT NULL,
    specialization_id integer
);


ALTER TABLE public.doctor OWNER TO admin;

--
-- Name: doctor_examination; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.doctor_examination (
    "doctorId" integer NOT NULL,
    "examinationId" integer NOT NULL
);


ALTER TABLE public.doctor_examination OWNER TO admin;

--
-- Name: doctor_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.doctor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_id_seq OWNER TO admin;

--
-- Name: doctor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.doctor_id_seq OWNED BY public.doctor.id;


--
-- Name: examination; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.examination (
    id integer NOT NULL,
    price integer NOT NULL,
    type character varying NOT NULL,
    specialization_id integer,
    "isPendingApproval" boolean DEFAULT false NOT NULL,
    "durationInMinutes" integer DEFAULT 30 NOT NULL
);


ALTER TABLE public.examination OWNER TO admin;

--
-- Name: examination_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.examination_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.examination_id_seq OWNER TO admin;

--
-- Name: examination_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.examination_id_seq OWNED BY public.examination.id;


--
-- Name: examination_request; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.examination_request (
    "doctorId" integer NOT NULL,
    "examinationId" integer NOT NULL
);


ALTER TABLE public.examination_request OWNER TO admin;

--
-- Name: manager; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.manager (
    id integer NOT NULL,
    "userName" character varying NOT NULL,
    password character varying NOT NULL,
    "firstName" character varying NOT NULL,
    "lastName" character varying NOT NULL,
    address character varying NOT NULL,
    phone character varying NOT NULL,
    email character varying NOT NULL
);


ALTER TABLE public.manager OWNER TO admin;

--
-- Name: manager_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.manager_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.manager_id_seq OWNER TO admin;

--
-- Name: manager_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.manager_id_seq OWNED BY public.manager.id;


--
-- Name: messageToManager; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."messageToManager" (
    id integer NOT NULL,
    message character varying NOT NULL,
    "doctorId" integer
);


ALTER TABLE public."messageToManager" OWNER TO admin;

--
-- Name: messageToManager_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."messageToManager_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."messageToManager_id_seq" OWNER TO admin;

--
-- Name: messageToManager_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."messageToManager_id_seq" OWNED BY public."messageToManager".id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.notification (
    id integer NOT NULL,
    read boolean DEFAULT false NOT NULL,
    message character varying NOT NULL,
    "patientId" integer
);


ALTER TABLE public.notification OWNER TO admin;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_id_seq OWNER TO admin;

--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- Name: patient; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.patient (
    id integer NOT NULL,
    "userName" character varying NOT NULL,
    password character varying NOT NULL,
    "firstName" character varying NOT NULL,
    "lastName" character varying NOT NULL,
    address character varying NOT NULL,
    phone character varying NOT NULL,
    email character varying NOT NULL,
    "profilePic" character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "registrationStatus" character varying DEFAULT 'pending'::character varying NOT NULL
);


ALTER TABLE public.patient OWNER TO admin;

--
-- Name: patient_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.patient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_id_seq OWNER TO admin;

--
-- Name: patient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.patient_id_seq OWNED BY public.patient.id;


--
-- Name: pendingRegistration; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."pendingRegistration" (
    id integer NOT NULL,
    "userName" character varying NOT NULL,
    password character varying NOT NULL,
    "firstName" character varying NOT NULL,
    "lastName" character varying NOT NULL,
    address character varying NOT NULL,
    phone character varying NOT NULL,
    email character varying NOT NULL,
    "profilePic" character varying
);


ALTER TABLE public."pendingRegistration" OWNER TO admin;

--
-- Name: pendingRegistration_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."pendingRegistration_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."pendingRegistration_id_seq" OWNER TO admin;

--
-- Name: pendingRegistration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."pendingRegistration_id_seq" OWNED BY public."pendingRegistration".id;


--
-- Name: report; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.report (
    id integer NOT NULL,
    diagnosis character varying NOT NULL,
    therapy character varying NOT NULL,
    "controlDate" timestamp without time zone NOT NULL,
    "controlTime" character varying NOT NULL,
    "scheduledExaminationId" integer
);


ALTER TABLE public.report OWNER TO admin;

--
-- Name: report_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.report_id_seq OWNER TO admin;

--
-- Name: report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.report_id_seq OWNED BY public.report.id;


--
-- Name: scheduledExamination; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."scheduledExamination" (
    id integer NOT NULL,
    "reasonForComing" character varying NOT NULL,
    date timestamp without time zone NOT NULL,
    examination_id integer,
    patient_id integer,
    doctor_id integer,
    "endTime" time without time zone NOT NULL,
    "startTime" time without time zone NOT NULL
);


ALTER TABLE public."scheduledExamination" OWNER TO admin;

--
-- Name: scheduledExamination_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."scheduledExamination_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."scheduledExamination_id_seq" OWNER TO admin;

--
-- Name: scheduledExamination_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."scheduledExamination_id_seq" OWNED BY public."scheduledExamination".id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.session (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "expiresAt" timestamp without time zone NOT NULL,
    "userRole" character varying NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public.session OWNER TO admin;

--
-- Name: specialization; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.specialization (
    id integer NOT NULL,
    type character varying NOT NULL
);


ALTER TABLE public.specialization OWNER TO admin;

--
-- Name: specialization_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.specialization_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.specialization_id_seq OWNER TO admin;

--
-- Name: specialization_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.specialization_id_seq OWNED BY public.specialization.id;


--
-- Name: doctor id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor ALTER COLUMN id SET DEFAULT nextval('public.doctor_id_seq'::regclass);


--
-- Name: examination id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.examination ALTER COLUMN id SET DEFAULT nextval('public.examination_id_seq'::regclass);


--
-- Name: manager id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.manager ALTER COLUMN id SET DEFAULT nextval('public.manager_id_seq'::regclass);


--
-- Name: messageToManager id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."messageToManager" ALTER COLUMN id SET DEFAULT nextval('public."messageToManager_id_seq"'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- Name: patient id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.patient ALTER COLUMN id SET DEFAULT nextval('public.patient_id_seq'::regclass);


--
-- Name: pendingRegistration id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."pendingRegistration" ALTER COLUMN id SET DEFAULT nextval('public."pendingRegistration_id_seq"'::regclass);


--
-- Name: report id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.report ALTER COLUMN id SET DEFAULT nextval('public.report_id_seq'::regclass);


--
-- Name: scheduledExamination id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."scheduledExamination" ALTER COLUMN id SET DEFAULT nextval('public."scheduledExamination_id_seq"'::regclass);


--
-- Name: specialization id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.specialization ALTER COLUMN id SET DEFAULT nextval('public.specialization_id_seq'::regclass);


--
-- Data for Name: doctor; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3636.dat

--
-- Data for Name: doctor_examination; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3649.dat

--
-- Data for Name: examination; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3638.dat

--
-- Data for Name: examination_request; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3650.dat

--
-- Data for Name: manager; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3630.dat

--
-- Data for Name: messageToManager; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3632.dat

--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3644.dat

--
-- Data for Name: patient; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3646.dat

--
-- Data for Name: pendingRegistration; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3648.dat

--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3640.dat

--
-- Data for Name: scheduledExamination; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3642.dat

--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3651.dat

--
-- Data for Name: specialization; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3634.dat

--
-- Name: doctor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.doctor_id_seq', 13, true);


--
-- Name: examination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.examination_id_seq', 29, true);


--
-- Name: manager_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.manager_id_seq', 1, false);


--
-- Name: messageToManager_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."messageToManager_id_seq"', 1, false);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.notification_id_seq', 1, false);


--
-- Name: patient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.patient_id_seq', 41, true);


--
-- Name: pendingRegistration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."pendingRegistration_id_seq"', 14, true);


--
-- Name: report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.report_id_seq', 33, true);


--
-- Name: scheduledExamination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."scheduledExamination_id_seq"', 42, true);


--
-- Name: specialization_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.specialization_id_seq', 28, true);


--
-- Name: examination_request PK_0e3e83dcc74df283c572f8424ab; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.examination_request
    ADD CONSTRAINT "PK_0e3e83dcc74df283c572f8424ab" PRIMARY KEY ("doctorId", "examinationId");


--
-- Name: scheduledExamination PK_19dd582333dc662b6fe19d04803; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."scheduledExamination"
    ADD CONSTRAINT "PK_19dd582333dc662b6fe19d04803" PRIMARY KEY (id);


--
-- Name: notification PK_705b6c7cdf9b2c2ff7ac7872cb7; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT "PK_705b6c7cdf9b2c2ff7ac7872cb7" PRIMARY KEY (id);


--
-- Name: doctor_examination PK_8096b10286c422ebdf7a58fb6e8; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor_examination
    ADD CONSTRAINT "PK_8096b10286c422ebdf7a58fb6e8" PRIMARY KEY ("doctorId", "examinationId");


--
-- Name: messageToManager PK_86759a567c5d35de2e73f0f5d81; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."messageToManager"
    ADD CONSTRAINT "PK_86759a567c5d35de2e73f0f5d81" PRIMARY KEY (id);


--
-- Name: patient PK_8dfa510bb29ad31ab2139fbfb99; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT "PK_8dfa510bb29ad31ab2139fbfb99" PRIMARY KEY (id);


--
-- Name: specialization PK_904dfcbdb57f56f5b57b9c09cc5; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.specialization
    ADD CONSTRAINT "PK_904dfcbdb57f56f5b57b9c09cc5" PRIMARY KEY (id);


--
-- Name: report PK_99e4d0bea58cba73c57f935a546; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT "PK_99e4d0bea58cba73c57f935a546" PRIMARY KEY (id);


--
-- Name: manager PK_b3ac840005ee4ed76a7f1c51d01; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT "PK_b3ac840005ee4ed76a7f1c51d01" PRIMARY KEY (id);


--
-- Name: pendingRegistration PK_c39a1178843a32fe46eda129382; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."pendingRegistration"
    ADD CONSTRAINT "PK_c39a1178843a32fe46eda129382" PRIMARY KEY (id);


--
-- Name: examination PK_de7c2a81d379fdf37174356fc12; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.examination
    ADD CONSTRAINT "PK_de7c2a81d379fdf37174356fc12" PRIMARY KEY (id);


--
-- Name: doctor PK_ee6bf6c8de78803212c548fcb94; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT "PK_ee6bf6c8de78803212c548fcb94" PRIMARY KEY (id);


--
-- Name: session PK_f55da76ac1c3ac420f444d2ff11; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT "PK_f55da76ac1c3ac420f444d2ff11" PRIMARY KEY (id);


--
-- Name: pendingRegistration UQ_240acba64667445914e64339075; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."pendingRegistration"
    ADD CONSTRAINT "UQ_240acba64667445914e64339075" UNIQUE ("userName");


--
-- Name: patient UQ_2c56e61f9e1afb07f28882fcebb; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT "UQ_2c56e61f9e1afb07f28882fcebb" UNIQUE (email);


--
-- Name: patient UQ_2e0161d2274de3efee02aca4dcf; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT "UQ_2e0161d2274de3efee02aca4dcf" UNIQUE ("userName");


--
-- Name: report UQ_35cd8ec8fabe7ba43d905f2c03f; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT "UQ_35cd8ec8fabe7ba43d905f2c03f" UNIQUE ("scheduledExaminationId");


--
-- Name: doctor UQ_91c53543bf9a22b538c8634873e; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT "UQ_91c53543bf9a22b538c8634873e" UNIQUE ("licenceNumber");


--
-- Name: doctor UQ_994f3dd0d4b33c5a2b171a9f383; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT "UQ_994f3dd0d4b33c5a2b171a9f383" UNIQUE ("userName");


--
-- Name: doctor UQ_bf6303ac911efaab681dc911f54; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT "UQ_bf6303ac911efaab681dc911f54" UNIQUE (email);


--
-- Name: manager UQ_ee8fba4edb704ce2465753a2edd; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT "UQ_ee8fba4edb704ce2465753a2edd" UNIQUE (email);


--
-- Name: manager UQ_f9f375808f4a346d22321cb8ed4; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT "UQ_f9f375808f4a346d22321cb8ed4" UNIQUE ("userName");


--
-- Name: pendingRegistration UQ_fe9cb44f3e01b0b963332f074ff; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."pendingRegistration"
    ADD CONSTRAINT "UQ_fe9cb44f3e01b0b963332f074ff" UNIQUE (email);


--
-- Name: IDX_1f5ad259811a7f0ed1ef00043f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_1f5ad259811a7f0ed1ef00043f" ON public.examination_request USING btree ("examinationId");


--
-- Name: IDX_6f19634d6421439d3904d7838c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_6f19634d6421439d3904d7838c" ON public.examination_request USING btree ("doctorId");


--
-- Name: IDX_b3130376268c7576886b7c6dbd; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_b3130376268c7576886b7c6dbd" ON public.doctor_examination USING btree ("examinationId");


--
-- Name: IDX_dd01b0e1615e8f26f2ed95d671; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_dd01b0e1615e8f26f2ed95d671" ON public.doctor_examination USING btree ("doctorId");


--
-- Name: examination_request FK_1f5ad259811a7f0ed1ef00043fa; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.examination_request
    ADD CONSTRAINT "FK_1f5ad259811a7f0ed1ef00043fa" FOREIGN KEY ("examinationId") REFERENCES public.examination(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: report FK_35cd8ec8fabe7ba43d905f2c03f; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT "FK_35cd8ec8fabe7ba43d905f2c03f" FOREIGN KEY ("scheduledExaminationId") REFERENCES public."scheduledExamination"(id);


--
-- Name: notification FK_58802f6c0c1f6a98f2b79d21a1a; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT "FK_58802f6c0c1f6a98f2b79d21a1a" FOREIGN KEY ("patientId") REFERENCES public.patient(id);


--
-- Name: examination FK_65feb56858d3b0d114307356d80; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.examination
    ADD CONSTRAINT "FK_65feb56858d3b0d114307356d80" FOREIGN KEY (specialization_id) REFERENCES public.specialization(id);


--
-- Name: examination_request FK_6f19634d6421439d3904d7838ce; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.examination_request
    ADD CONSTRAINT "FK_6f19634d6421439d3904d7838ce" FOREIGN KEY ("doctorId") REFERENCES public.doctor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctor FK_770f8e79222b0b3f46fad126b32; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT "FK_770f8e79222b0b3f46fad126b32" FOREIGN KEY (specialization_id) REFERENCES public.specialization(id);


--
-- Name: messageToManager FK_7db15f38e20a12d239392c56df5; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."messageToManager"
    ADD CONSTRAINT "FK_7db15f38e20a12d239392c56df5" FOREIGN KEY ("doctorId") REFERENCES public.doctor(id);


--
-- Name: scheduledExamination FK_8729052ba58d6c29568b3169dc4; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."scheduledExamination"
    ADD CONSTRAINT "FK_8729052ba58d6c29568b3169dc4" FOREIGN KEY (examination_id) REFERENCES public.examination(id);


--
-- Name: scheduledExamination FK_99129b2ebe16a615e47667a3425; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."scheduledExamination"
    ADD CONSTRAINT "FK_99129b2ebe16a615e47667a3425" FOREIGN KEY (patient_id) REFERENCES public.patient(id) ON DELETE CASCADE;


--
-- Name: doctor_examination FK_b3130376268c7576886b7c6dbd1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor_examination
    ADD CONSTRAINT "FK_b3130376268c7576886b7c6dbd1" FOREIGN KEY ("examinationId") REFERENCES public.examination(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctor_examination FK_dd01b0e1615e8f26f2ed95d671d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.doctor_examination
    ADD CONSTRAINT "FK_dd01b0e1615e8f26f2ed95d671d" FOREIGN KEY ("doctorId") REFERENCES public.doctor(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scheduledExamination FK_f25288b5b1761de04d0b772993b; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."scheduledExamination"
    ADD CONSTRAINT "FK_f25288b5b1761de04d0b772993b" FOREIGN KEY (doctor_id) REFERENCES public.doctor(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

